export default function PersonaForm({ persona, setPersona, guardar }) {
  return (
    <form onSubmit={guardar}>
      <input placeholder="Nombre" value={persona.nombre}
        onChange={(e)=>setPersona({...persona, nombre:e.target.value})}/>
      <input placeholder="Apellido" value={persona.apellido}
        onChange={(e)=>setPersona({...persona, apellido:e.target.value})}/>
      <input placeholder="Correo" value={persona.correo}
        onChange={(e)=>setPersona({...persona, correo:e.target.value})}/>
      <input placeholder="Documento" value={persona.documento}
        onChange={(e)=>setPersona({...persona, documento:e.target.value})}/>
      <button>Guardar</button>
    </form>
  );
}




