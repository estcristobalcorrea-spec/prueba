export default function FormularioBase({ persona, setPersona, onSubmit, titulo }) {
  return (
    <form onSubmit={onSubmit} style={{maxWidth:"400px"}}>
      <h2>{titulo}</h2>

      <label>Nombre</label><br/>
      <input value={persona.Nombre} onChange={e=>setPersona({...persona,Nombre:e.target.value})} /><br/>

      <label>Apellido</label><br/>
      <input value={persona.Apellido} onChange={e=>setPersona({...persona,Apellido:e.target.value})} /><br/>

      <label>Documento</label><br/>
      <input value={persona.Documento} onChange={e=>setPersona({...persona,Documento:e.target.value})} /><br/>

      <label>Correo</label><br/>
      <input value={persona.Correo} onChange={e=>setPersona({...persona,Correo:e.target.value})} /><br/><br/>

      <button>Guardar</button>
    </form>
  );
}








