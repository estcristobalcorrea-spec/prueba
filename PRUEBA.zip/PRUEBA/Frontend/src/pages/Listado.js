import { useEffect, useState } from "react";
import { obtenerPersonas, eliminarPersona } from "../api/personasApi";
import { Link } from "react-router-dom";

export default function Listado() {
  const [personas, setPersonas] = useState([]);
  const [busqueda, setBusqueda] = useState("");

  const cargar = async () => {
    try {
      const res = await obtenerPersonas();
      setPersonas(res.data);
    } catch (e) {
      console.log(e);
    }
  };

  useEffect(() => {
    cargar();
  }, []);

  const borrar = async (id) => {
    if (window.confirm("¿Seguro que deseas eliminar esta persona?")) {
      await eliminarPersona(id);
      cargar(); // recargar lista
    }
  };

  // 🔎 Filtrar por nombre o apellido
  const personasFiltradas = personas.filter((p) =>
    (p.nombre || "").toLowerCase().includes(busqueda.toLowerCase())
  );

  return (
    <div>
      <h1>Listado</h1>

      {/* 🔎 Buscador */}
      <input
        type="text"
        placeholder="Buscar por nombre..."
        value={busqueda}
        onChange={(e) => setBusqueda(e.target.value)}
        style={{ marginBottom: "20px", padding: "5px" }}
      />

      <hr />

      {personasFiltradas.length === 0 && (
        <p>No hay registros o no se encontraron resultados.</p>
      )}

      <ul>
        {personasFiltradas.map((p) => (
          <li key={p.id} style={{ marginBottom: "20px" }}>

            {/* 🔹 FORMULARIO A */}
            {(p.nombre || p.apellido || p.documento || p.correo) && (
              <>
                <h3>📌 FORMULARIO A</h3>
                {p.nombre && p.apellido && <p>👤 {p.nombre} {p.apellido}</p>}
                {p.documento && <p>🪪 Documento: {p.documento}</p>}
                {p.correo && <p>📨 Correo: {p.correo.toLowerCase()}</p>}
              </>
            )}

            {/* 🔹 FORMULARIO B */}
            {(p.telefono || p.edad) && (
              <>
                <h3>📌 FORMULARIO B</h3>
                {p.telefono && <p>📞 Teléfono: {p.telefono}</p>}
                {p.edad && <p>🎂 Edad: {p.edad}</p>}
              </>
            )}

            <Link to={`/Editar/${p.id}`}>✏️ Editar</Link>
            {" | "}
            <button onClick={() => borrar(p.id)}>🗑️ Eliminar</button>

            <hr />
          </li>
        ))}
      </ul>
    </div>
  );
}













