import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { obtenerPersona, actualizarPersona } from "../api/personasApi";

export default function Editar() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [persona, setPersona] = useState({});
  const [tipo, setTipo] = useState("");

  useEffect(() => {
    const cargar = async () => {
      try {
        const { data } = await obtenerPersona(id);
        setPersona(data);

        if (data.telefono || data.edad) setTipo("B");
        else setTipo("A");

      } catch {
        alert("Error cargando datos");
      }
    };
    cargar();
  }, [id]);

  const handle = (e) =>
    setPersona({ ...persona, [e.target.name]: e.target.value });

  const guardar = async () => {
    try {
      await actualizarPersona(id, persona);
      alert("Guardado correctamente");
      navigate("/Listado");
    } catch {
      alert("Error al guardar datos");
    }
  };

  return (
    <div>
      <h1>Editar Persona #{id}</h1>

      {tipo === "A" && (
        <>
          <h3>📌 Formulario A</h3>
          <input name="nombre" value={persona.nombre || ""} onChange={handle} placeholder="Nombre" /><br />
          <input name="apellido" value={persona.apellido || ""} onChange={handle} placeholder="Apellido" /><br />
          <input name="documento" value={persona.documento || ""} onChange={handle} placeholder="Documento" /><br />
          <input name="correo" value={persona.correo || ""} onChange={handle} placeholder="Correo" /><br />
        </>
      )}

      {tipo === "B" && (
        <>
          <h3>📌 Formulario B</h3>
          <input name="telefono" value={persona.telefono || ""} onChange={handle} placeholder="Teléfono" /><br />
          <input name="edad" value={persona.edad || ""} onChange={handle} placeholder="Edad" /><br />
        </>
      )}

      <button onClick={guardar}>💾 Guardar Cambios</button>
    </div>
  );
}


