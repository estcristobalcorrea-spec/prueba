import { useState } from "react";
import { crearPersona } from "../api/personasApi";

export default function FormularioA() {
  const [persona, setPersona] = useState({
    nombre: "",
    apellido: "",
    documento: "",
    correo: ""
  });

  const enviar = async (e) => {
    e.preventDefault();
    await crearPersona(persona);
    alert("Guardado desde A ✔️");
    setPersona({ nombre: "", apellido: "", documento: "", correo: "" });
  };

  return (
    <>
      <h1>Formulario A</h1>
      <form onSubmit={enviar}>
        <input placeholder="Nombre" value={persona.nombre} onChange={e => setPersona({ ...persona, nombre: e.target.value })} /><br/>
        <input placeholder="Apellido" value={persona.apellido} onChange={e => setPersona({ ...persona, apellido: e.target.value })} /><br/>
        <input placeholder="Documento" value={persona.documento} onChange={e => setPersona({ ...persona, documento: e.target.value })} /><br/>
        <input placeholder="Correo" value={persona.correo} onChange={e => setPersona({ ...persona, correo: e.target.value })} /><br/><br/>
        <button>Guardar</button>
      </form>
    </>
  );
}















