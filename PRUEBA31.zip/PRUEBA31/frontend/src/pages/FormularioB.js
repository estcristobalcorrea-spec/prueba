import { useState } from "react";
import { crearPersona } from "../api/personasApi";

export default function FormularioB(){
  const [persona, setPersona] = useState({
    telefono: "",
    edad: ""
  });

  const enviar = async(e)=>{
    e.preventDefault();
    await crearPersona(persona);
    alert("Guardado desde B ✔️");
    setPersona({ telefono: "", edad: "" });
  };

  return (
    <>
      <h1>Formulario B</h1>
      <form onSubmit={enviar}>
        <input placeholder="Teléfono" value={persona.telefono} onChange={e=>setPersona({...persona, telefono:e.target.value})}/><br/>
        <input placeholder="Edad" type="number" value={persona.edad} onChange={e=>setPersona({...persona, edad:e.target.value})}/><br/><br/>
        <button>Guardar</button>
      </form>
    </>
  );
}

















