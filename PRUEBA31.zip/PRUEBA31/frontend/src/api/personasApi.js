import axios from "axios";

const API = "http://localhost:5100/api/Personas";

export const obtenerPersonas = () => axios.get(API);
export const obtenerPersona = (id) => axios.get(`${API}/${id}`);
export const crearPersona = (data) => axios.post(API, data);
export const actualizarPersona = (id, data) => axios.put(`${API}/${id}`, data);
export const eliminarPersona = (id) => axios.delete(`${API}/${id}`);  















