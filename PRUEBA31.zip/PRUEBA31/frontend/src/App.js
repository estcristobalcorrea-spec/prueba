import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import FormularioA from "./pages/FormularioA";
import FormularioB from "./pages/FormularioB";
import Listado from "./pages/Listado";
import EditarPersona from "./pages/EditarPersona";

export default function App() {
  return (
    <BrowserRouter>

      <nav style={{padding:"10px", marginBottom:"20px", borderBottom:"1px solid #ccc"}}>
        <Link to="/FormularioA" style={{marginRight:"20px"}}>Formulario A</Link>
        <Link to="/FormularioB" style={{marginRight:"20px"}}>Formulario B</Link>
        <Link to="/Listado">Listado</Link>
      </nav>

      <Routes>
        <Route path="/" element={<FormularioA/>}/>
        <Route path="/FormularioA" element={<FormularioA/>}/>
        <Route path="/FormularioB" element={<FormularioB/>}/>
        <Route path="/Listado" element={<Listado/>}/>
        <Route path="/Editar/:id" element={<EditarPersona/>}/>
      </Routes>

    </BrowserRouter>
  );
}






















